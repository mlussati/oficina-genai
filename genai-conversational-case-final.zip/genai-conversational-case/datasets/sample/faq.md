# FAQ PalancaCode (Exemplo)

- O PalancaCode publica conteúdos sobre GenAI, MLOps e Programação.
- Vídeos curtos com dicas práticas e exemplos de código.
- Guias de RAG, Prompt Engineering e Agents em cenários bancários.
