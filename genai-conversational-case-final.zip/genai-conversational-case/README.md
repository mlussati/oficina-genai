# Conversational GenAI Case — Template (AI-Adoption)

Este template cria um **case conversacional** padronizado para o **HUB de Templates de AI-Adoption**.

Ele integra:

- SDK interno **`genaisdk`** (Client, Pipeline, submit)
- opção de **backend HTTP** direto para a API da plataforma
- **pipeline conversacional com RAG mínimo (TF-IDF)**
- **guardrails básicos** (detecção simples de PII)
- **fallback HITL** (retorno `HITL_REQUIRED`)
- **telemetria/observabilidade** via logs JSON e webhook opcional
- notebooks prontos para exploração do SDK

## Objetivo do case

Mostrar para times de produto, dados e negócio como:

1. Descobrir recursos da plataforma de GenAI (projetos, usuário, créditos).
2. Listar modelos e guardrails disponíveis.
3. Criar um **Pipeline simples** usando o SDK (`Pipeline` + `submit`).
4. Consumir um **pipeline de chat estruturado** (com RAG e guardrails) via função Python e via CLI.
5. Ter uma base que possa ser clonada, configurada e publicada no HUB de templates.

---

## Estrutura do projeto

```text
genai-conversational-case/
├── Makefile
├── pyproject.toml
├── requirements.txt
├── dev-requirements.txt
├── .env.example
├── README.md
├── notebooks/
│   └── 01_quickstart.ipynb
├── datasets/
│   └── sample/
│       └── faq.md
├── src/
│   └── ai_conv_case/
│       ├── __init__.py
│       ├── config.py
│       ├── telemetry.py
│       ├── clients/
│       │   └── platform.py
│       ├── rag/
│       │   ├── retriever.py
│       │   └── ingest.py
│       ├── guardrails/
│       │   ├── policy.yaml
│       │   └── validators.py
│       ├── pipelines/
│       │   └── chat.py
│       └── evaluation/
│           └── eval.py
└── tests/
    └── test_smoke.py
```

---

## Backend modular (SDK x HTTP)

Você pode escolher como falar com a plataforma:

- **SDK (`genaisdk`)** — recomendado em notebooks internos e POCs.
- **HTTP direto** — útil quando o SDK não está disponível no ambiente.

Controle via variável de ambiente:

```bash
# usar SDK (genaisdk)
export GENAI_BACKEND=SDK

# usar HTTP cru (REST)
export GENAI_BACKEND=HTTP

# se não definir, o template tenta SDK e cai para HTTP se o pacote não existir
```

### Onde os métodos do SDK aparecem

No arquivo `src/ai_conv_case/clients/platform.py` o `SDKBackend` usa um `Client` do SDK
e expõe helpers para uso em notebooks:

- `list_projects_via_sdk()` → `client.list_projects()`
- `list_models_via_sdk()`   → `client.get_models()`
- `get_guardrails_via_sdk()`→ `client.get_guardrails()`

O pipeline de chat usa `Client.submit(...)` com um `Pipeline` criado em código.

---

## Instalação rápida

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

pip install -r requirements.txt
pip install -r dev-requirements.txt   # opcional
pip install -e .

cp .env.example .env
# edite GENAI_API_BASE, GENAI_API_KEY, GENAI_DEFAULT_MODEL
```

---

## Usando o notebook `01_quickstart.ipynb`

No notebook você verá seções:

1. **Conectando no SDK** (`Client`, `Pipeline`).
2. **Explorando o ambiente** (projetos, usuário, créditos).
3. **Modelos e guardrails disponíveis**.
4. **Exemplo de Pipeline com prompt direto** (espelhando o exemplo oficial).
5. **Exemplo de chat estruturado com RAG** usando `run_chat` do pacote.

---

## Usando o pipeline de chat via código

```python
from ai_conv_case.pipelines.chat import run_chat

resp = run_chat(
    "Explique RAG em 3 bullets.",
    meta={"canal": "notebook", "time": "AI-Adoption"},
)

if resp["status"] == "OK":
    print(resp["content"])
else:
    print(resp)
```

Via CLI:

```bash
make chat prompt="Explique RAG em 3 bullets."
```

---

## Variáveis principais de ambiente (.env)

```env
GENAI_API_KEY=seu_token_aqui
GENAI_API_BASE=https://sua-api-genai
GENAI_DEFAULT_MODEL=amazon-nova-lite-v1
GENAI_TEMPERATURE=0.2
GENAI_MAX_TOKENS=1024

APP_ENV=dev
LOG_LEVEL=INFO

# Observabilidade (opcional)
OBS_ENDPOINT=
```

---

## Roadmap sugerido

- [ ] Adicionar store vetorial corporativa (FAISS/Chroma) com embeddings da plataforma.
- [ ] Incluir notebook `02_eval.ipynb` com avaliação offline (latência, qualidade, groundedness).
- [ ] Conectar saída `HITL_REQUIRED` a um fluxo real (fila de atendimento / ServiceNow / Teams).
- [ ] Adicionar exemplos de pipelines com ferramentas (tool-calling) e múltiplos passos.
