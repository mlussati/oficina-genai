from ai_conv_case.pipelines.chat import run_chat

def test_smoke_callable():
    assert callable(run_chat)
