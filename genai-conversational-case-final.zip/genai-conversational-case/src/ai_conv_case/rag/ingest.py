import os
import glob
from typing import List

from .retriever import SimpleTfidfRetriever, Doc

def load_txts(path: str) -> List[Doc]:
    docs: List[Doc] = []
    for fp in glob.glob(os.path.join(path, "*.txt")) + glob.glob(os.path.join(path, "*.md")):
        with open(fp, "r", encoding="utf-8", errors="ignore") as f:
            txt = f.read()
        docs.append(Doc(id=os.path.basename(fp), text=txt, meta={"path": fp}))
    return docs

def build_retriever(dataset_dir: str) -> SimpleTfidfRetriever:
    r = SimpleTfidfRetriever()
    docs = load_txts(dataset_dir)
    if docs:
        r.add(docs)
    return r
