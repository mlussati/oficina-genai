from dataclasses import dataclass
from typing import List, Tuple
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

@dataclass
class Doc:
    id: str
    text: str
    meta: dict

class SimpleTfidfRetriever:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(max_df=0.9, min_df=1, ngram_range=(1, 2))
        self._docs: List[Doc] = []
        self._X = None

    def add(self, docs: List[Doc]) -> None:
        self._docs.extend(docs)
        texts = [d.text for d in self._docs]
        self._X = self.vectorizer.fit_transform(texts)

    def query(self, q: str, k: int = 3) -> List[Tuple[Doc, float]]:
        if not self._docs or self._X is None:
            return []
        qv = self.vectorizer.transform([q])
        sims = cosine_similarity(qv, self._X).ravel()
        idxs = sims.argsort()[::-1][:k]
        return [(self._docs[i], float(sims[i])) for i in idxs]
