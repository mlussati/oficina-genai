from typing import Optional, Dict, Any, List
import json
import os

import typer

from ..clients.platform import get_backend
from ..telemetry import get_logger, traced, emit_observable
from ..guardrails.validators import has_pii
from ..rag.ingest import build_retriever

app = typer.Typer(help="Pipeline de chat conversacional (CLI com RAG e HITL)")

logger = get_logger("chat")
DATASET_DIR = os.getenv("DATASET_DIR", "datasets/sample")

def build_messages(prompt: str, contexts: List[str]) -> List[Dict[str, str]]:
    system = (
        "Você é um assistente da AI-Adoption / PalancaCode. "
        "Seja didático, direto e, quando fizer sentido, cite o contexto usado no final."
    )
    if contexts:
        ctx_block = "\n\n".join([f"- {c[:600]}" for c in contexts])
    else:
        ctx_block = "Nenhum contexto relevante encontrado."
    augmented = (
        "Use o contexto abaixo se for relevante à pergunta. "
        "Se não for, responda normalmente.\n\n"
        f"Contexto:\n{ctx_block}\n\n"
        f"Pergunta do usuário: {prompt}"
    )
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": augmented},
    ]

def run_chat(prompt: str, meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    meta = meta or {}

    if has_pii(prompt):
        emit_observable("guardrail.blocked_input", {"reason": "pii_detected"})
        return {
            "status": "HITL_REQUIRED",
            "reason": "PII detectada no input. Encaminhar para humano.",
        }

    with traced("rag.retrieve", logger):
        retriever = build_retriever(DATASET_DIR)
        results = retriever.query(prompt, k=3)
        contexts = [d.text for d, score in results if score > 0.05]

    backend = get_backend()
    messages = build_messages(prompt, contexts)

    with traced("genai.chat", logger, meta={"k_ctx": len(contexts)}):
        try:
            result = backend.chat(messages=messages, meta=meta)
            # Caso SDK: assume estrutura response["output"]["router"]["content"]
            if "output" in result and "router" in result["output"]:
                content = result["output"]["router"].get("content", "")
            else:
                content = (
                    result.get("choices", [{}])[0]
                    .get("message", {})
                    .get("content", "")
                )
        except Exception as e:
            emit_observable("model.error", {"error": repr(e)})
            return {
                "status": "ERROR",
                "error": repr(e),
                "hint": "Verifique credenciais, endpoint, GENAI_BACKEND e conectividade com a plataforma.",
            }

    if has_pii(content):
        emit_observable("guardrail.blocked_output", {"reason": "pii_detected"})
        return {
            "status": "HITL_REQUIRED",
            "reason": "PII detectada na saída do modelo. Encaminhar para humano.",
        }

    emit_observable("chat.success", {"chars": len(content)})
    return {"status": "OK", "content": content, "contexts_used": len(contexts)}

@app.command()
def main(
    prompt: str,
    meta: str = typer.Option("{}", help="JSON string com metadados"),
) -> None:
    meta_dict = json.loads(meta) if meta else {}
    out = run_chat(prompt, meta=meta_dict)
    print(json.dumps(out, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    app()
