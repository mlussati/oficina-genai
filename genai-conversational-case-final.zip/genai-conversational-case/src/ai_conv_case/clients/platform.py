from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Protocol, runtime_checkable
import os

import httpx

from ..config import settings
from ..telemetry import get_logger

try:
    from genaisdk import Client as GenAIClientSDK, Pipeline  # type: ignore
except Exception:  # pragma: no cover
    GenAIClientSDK = None  # type: ignore
    Pipeline = None  # type: ignore

logger = get_logger("platform")

@runtime_checkable
class ChatBackend(Protocol):
    def chat(
        self,
        *,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        meta: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        ...

@dataclass
class SDKBackend(ChatBackend):
    client: Any

    @classmethod
    def from_env(cls) -> "SDKBackend":
        if GenAIClientSDK is None:
            raise RuntimeError("genaisdk não está instalado ou não pôde ser importado.")
        client = GenAIClientSDK(
            api_key=settings.genai_api_key.get_secret_value(),
            base_url=settings.genai_api_base,
        )
        return cls(client=client)

    def _build_prompt_from_messages(self, messages: List[Dict[str, str]]) -> str:
        parts = []
        for m in messages:
            role = m.get("role", "user")
            content = m.get("content", "")
            if role == "system":
                parts.append(f"[SYSTEM] {content}")
            elif role == "assistant":
                parts.append(f"[ASSISTANT] {content}")
            else:
                parts.append(f"[USER] {content}")
        return "\n".join(parts)

    def chat(
        self,
        *,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        meta: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if Pipeline is None:
            raise RuntimeError("Pipeline não disponível no genaisdk.")

        routing_model = model or settings.genai_default_model
        temp = temperature if temperature is not None else settings.genai_temperature

        pipe_llm = Pipeline()
        pipe_llm.add_llm_step(
            llm_input="${input.prompt}",
            routing_model=routing_model,
            temperature=temp,
        )

        prompt_str = self._build_prompt_from_messages(messages)
        payload = {"prompt": prompt_str}

        logger.info("Enviando request via SDK (Client.submit + Pipeline)")
        response = self.client.submit(
            pipeline_input=payload,
            pipeline=pipe_llm,
            metadata=meta or {},
        )
        return response

@dataclass
class HTTPBackend(ChatBackend):
    api_key: str
    base_url: str

    @classmethod
    def from_env(cls) -> "HTTPBackend":
        return cls(
            api_key=settings.genai_api_key.get_secret_value().strip(),
            base_url=settings.genai_api_base.rstrip("/"),
        )

    def chat(
        self,
        *,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        meta: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "model": model or settings.genai_default_model,
            "messages": messages,
            "temperature": temperature if temperature is not None else settings.genai_temperature,
            "max_tokens": max_tokens if max_tokens is not None else settings.genai_max_tokens,
            "metadata": meta or {},
        }
        url = f"{self.base_url}/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        logger.info("Enviando request via HTTP direto")
        with httpx.Client(timeout=60) as client:
            resp = client.post(url, headers=headers, json=payload)
            resp.raise_for_status()
            return resp.json()

def get_backend() -> ChatBackend:
    backend = os.getenv("GENAI_BACKEND", "").upper()
    if backend == "SDK":
        if GenAIClientSDK is None:
            raise RuntimeError("GENAI_BACKEND=SDK mas genaisdk não está disponível.")
        return SDKBackend.from_env()
    if backend == "HTTP":
        return HTTPBackend.from_env()
    if GenAIClientSDK is not None:
        return SDKBackend.from_env()
    return HTTPBackend.from_env()

# Helpers para notebooks
def list_projects_via_sdk() -> Any:
    if GenAIClientSDK is None:
        raise RuntimeError("genaisdk não está disponível.")
    client = SDKBackend.from_env().client
    return client.list_projects()

def list_models_via_sdk() -> Any:
    if GenAIClientSDK is None:
        raise RuntimeError("genaisdk não está disponível.")
    client = SDKBackend.from_env().client
    return client.get_models()

def get_guardrails_via_sdk() -> Any:
    if GenAIClientSDK is None:
        raise RuntimeError("genaisdk não está disponível.")
    client = SDKBackend.from_env().client
    return client.get_guardrails()
