from pydantic_settings import BaseSettings
from pydantic import SecretStr

class Settings(BaseSettings):
    genai_api_key: SecretStr
    genai_api_base: str
    genai_default_model: str = "amazon-nova-lite-v1"
    genai_temperature: float = 0.2
    genai_max_tokens: int = 1024

    app_env: str = "dev"
    log_level: str = "INFO"

    class Config:
        env_file = ".env"
        case_sensitive = False

settings = Settings()
