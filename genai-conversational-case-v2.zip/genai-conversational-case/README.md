# Conversational GenAI Case — Template (AI-Adoption)

Este template cria um **case conversacional** padronizado para o **HUB de Templates de AI-Adoption**.
Ele integra **SDK da sua plataforma de GenAI**, **RAG mínimo (TF‑IDF)**, **guardrails básicos**, **telemetria/observabilidade** e **fallback para humano (HITL)**. Pode ser usado em **notebooks** ou **via CLI**.

## Para que serve
- **Acelerar POCs** e replicação de um case conversacional em diferentes áreas.
- **Padronizar** estrutura (config, clientes, pipelines, guardrails, avaliação e telemetria).
- **Facilitar consumo em notebook** (demos, workshops, imersões) e **execução via CLI** em CI/CD.

## Principais componentes
- **SDK/HTTP client** (`src/ai_conv_case/clients/platform.py`): troque pelo SDK oficial da plataforma.
- **Pipeline de chat** com **RAG** e **HITL** (`src/ai_conv_case/pipelines/chat.py`).
- **Guardrails** (`src/ai_conv_case/guardrails/*`): PII simples e política YAML.
- **Telemetria/Observabilidade** (`src/ai_conv_case/telemetry.py`): logs JSON e **webhook opcional** (`OBS_ENDPOINT`).
- **Avaliação** (`src/ai_conv_case/evaluation/eval.py`): hooks para medir latência e sucesso.
- **Datasets** (`datasets/sample`): base local simples para o RAG mínimo.

## Instalação rápida
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pip install -r dev-requirements.txt   # opcional
pip install -e .
cp .env.example .env
# edite GENAI_API_BASE, GENAI_API_KEY, GENAI_DEFAULT_MODEL
```

## Como usar
### Notebook
Abra `notebooks/01_quickstart.ipynb` e rode as células. Exemplo:
```python
from ai_conv_case.pipelines.chat import run_chat
resp = run_chat("Explique RAG em 3 bullets.", meta={"channel":"notebook"})
resp["content"]
```

### CLI
```bash
make chat prompt="Como usar RAG neste case?"
```

### RAG mínimo (TF‑IDF)
- Arquivos em `datasets/sample/*.md|*.txt` são ingeridos por um **retriever TF‑IDF** (leve e sem embeddings).
- Ajuste `DATASET_DIR` via env var para apontar outra pasta de conhecimento.
- Para embeddings e vetorização densa, substitua `SimpleTfidfRetriever` por sua store vetorial.

## HITL (Fallback para humano)
Casos que disparam HITL no exemplo:
1. **PII no input** (CPF simples) → bloqueia e retorna `HITL_REQUIRED`.
2. **PII na saída** → bloqueia e retorna `HITL_REQUIRED`.

Expanda com outras regras (tópicos bloqueados, confiança baixa, políticas internas).
Integre o retorno `HITL_REQUIRED` ao seu **workflow de atendimento humano**.

## Observabilidade
- Logs estruturados JSON via `get_logger`.
- Webhook opcional: defina `OBS_ENDPOINT` (HTTP POST) para receber **eventos**:
  - `guardrail.blocked_input`, `guardrail.blocked_output`
  - `model.error`, `chat.success`

## Onde plugar o SDK da Plataforma
Em `src/ai_conv_case/clients/platform.py` troque o wrapper HTTP por **imports do SDK oficial** e ajuste:
- **Auth** (chaves, rotas privadas/corporativas)
- **Endpoint** de chat (ex.: `/v1/chat/completions`)
- **Parâmetros de modelos** (temperatura, max_tokens, sistema, metadata)

## Testes e Qualidade
```bash
make test
make lint
make fmt
```

## Variáveis principais (.env)
```
GENAI_API_KEY=...
GENAI_API_BASE=https://api.sua-plataforma-genai.com
GENAI_DEFAULT_MODEL=gpt-like-4o-mini
GENAI_TEMPERATURE=0.2
GENAI_MAX_TOKENS=1024

APP_ENV=dev
LOG_LEVEL=INFO

# Observabilidade (opcional)
OBS_ENDPOINT=
```

## Roadmap sugerido (para o HUB)
- [ ] Adicionar **storage vetorial** (FAISS/Chroma) e **embeddings corporativos**.
- [ ] Implementar **RAG avaliativo** (gradio demo + métricas de groundedness).
- [ ] Conectar **HITL** à fila/desk corporativo (ex.: ServiceNow/Jira/Teams).
- [ ] Expor **config por feature flag** para alternar modelos/roteadores/guardrails.
- [ ] Criar **notebook 02_eval.ipynb** com avaliação offline + amostras rotuladas.
