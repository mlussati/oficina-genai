from ai_conv_case.pipelines.chat import run_chat

def test_smoke_import():
    assert callable(run_chat)
