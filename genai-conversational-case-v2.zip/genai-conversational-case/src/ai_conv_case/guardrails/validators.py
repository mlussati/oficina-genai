import re

PII_REGEX = re.compile(r"\b(\d{3}\.\d{3}\.\d{3}-\d{2}|\d{11})\b")  # cpf simples

def has_pii(text: str) -> bool:
    return bool(PII_REGEX.search(text or ""))
