from typing import Dict, Any, Optional
import httpx
from ..config import settings

class GenAIClient:
    """Wrapper minimalista para o SDK/HTTP da sua plataforma de GenAI.
    Substitua por imports do SDK oficial quando possível.
    """
    def __init__(self, api_key: str | None = None, base_url: str | None = None):
        self.api_key = (api_key or settings.genai_api_key.get_secret_value()).strip()
        self.base_url = (base_url or settings.genai_api_base).rstrip("/")

        self._headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def chat(self, *, messages: list[Dict[str, str]],
             model: Optional[str] = None,
             temperature: Optional[float] = None,
             max_tokens: Optional[int] = None,
             meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:

        payload = {
            "model": model or settings.genai_default_model,
            "messages": messages,
            "temperature": temperature if temperature is not None else settings.genai_temperature,
            "max_tokens": max_tokens if max_tokens is not None else settings.genai_max_tokens,
            "metadata": meta or {},
        }
        # Troque o endpoint abaixo pelo da sua plataforma (ex.: /v1/chat/completions)
        url = f"{self.base_url}/v1/chat/completions"
        with httpx.Client(timeout=60) as client:
            resp = client.post(url, headers=self._headers, json=payload)
            resp.raise_for_status()
            return resp.json()
