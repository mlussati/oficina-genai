import logging
import os
import json
from contextlib import contextmanager
from time import perf_counter
from typing import Any, Dict, Optional
import httpx

class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "level": record.levelname,
            "name": record.name,
            "message": record.getMessage(),
        }
        if hasattr(record, "extra"):
            payload.update(record.extra)  # type: ignore
        return json.dumps(payload, ensure_ascii=False)

def get_logger(name: str = "ai_conv_case"):
    level = os.getenv("LOG_LEVEL", "INFO").upper()
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    logger = logging.getLogger(name)
    logger.handlers = []
    logger.addHandler(handler)
    logger.setLevel(level)
    logger.propagate = False
    return logger

def emit_observable(event: str, data: Dict[str, Any] | None = None, timeout: float = 3.0) -> None:
    endpoint = os.getenv("OBS_ENDPOINT")
    if not endpoint:
        return
    payload = {"event": event, "data": data or {}}
    try:
        with httpx.Client(timeout=timeout) as client:
            client.post(endpoint, json=payload)
    except Exception:
        # best effort only
        pass

@contextmanager
def traced(op: str, logger=None, meta: Optional[Dict[str, Any]] = None):
    logger = logger or get_logger()
    start = perf_counter()
    if meta is None:
        meta = {}
    logger.info(json.dumps({"op": op, "phase": "start", **meta}, ensure_ascii=False))
    try:
        yield
    finally:
        dur = (perf_counter() - start) * 1000
        logger.info(json.dumps({"op": op, "phase": "end", "duration_ms": round(dur, 2), **meta}, ensure_ascii=False))
