from dataclasses import dataclass
from time import perf_counter
from typing import Callable, Dict, Any

@dataclass
class EvalResult:
    latency_ms: float
    ok: bool
    notes: str

def timed_eval(fn: Callable[[], str]) -> EvalResult:
    start = perf_counter()
    try:
        out = fn()
        ok = bool(out and len(out.strip()) > 0)
        notes = f"len_out={len(out)}"
    except Exception as e:
        ok = False
        notes = f"error={e!r}"
    dur = (perf_counter() - start) * 1000
    return EvalResult(latency_ms=dur, ok=ok, notes=notes)
