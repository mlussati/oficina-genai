# Conversational GenAI Case — Template (AI-Adoption, backend modular)

Este template está preparado para usar o SDK interno `genaisdk` **ou** chamadas HTTP diretas
para a plataforma de GenAI, mantendo o pipeline de chat desacoplado via uma interface única
(`ChatBackend`).

## Escolhendo o backend

```bash
# usar SDK (genaisdk)
export GENAI_BACKEND=SDK

# usar HTTP cru (chamada REST)
export GENAI_BACKEND=HTTP

# se não definir, o template tenta SDK e cai para HTTP se o pacote não existir
```

## Como o SDK é usado

No arquivo `src/ai_conv_case/clients/platform.py` o `SDKBackend` usa a classe `Client` do SDK
(`genaisdk.Client`) e centraliza a chamada de chat em `client.submit(...)`.

Métodos previstos pelo SDK que você pode aproveitar em notebooks ou ferramentas:

- `client.get_guardrails()` → exposto como `get_guardrails_via_sdk()`
- `client.get_models()` / `client.list_models()` → exposto como `list_models_via_sdk()`
- `client.list_projects()` / `client.projects()` → exposto como `list_projects_via_sdk()`
- `client.submit(...)` → usado como canal único para enviar requisições de chat neste template.

Ajuste os parâmetros do `submit` (por exemplo `task_type`, `project_id`, etc.) de acordo com
o contrato real da sua plataforma. O resto do pipeline (RAG, guardrails, HITL) permanece igual.
