from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Protocol, runtime_checkable
import os

import httpx

from ..config import settings
from ..telemetry import get_logger

# Import opcional do SDK.
# Se não estiver instalado, o backend HTTP continua funcionando.
try:
    from genaisdk import Client as GenAIClientSDK  # type: ignore
except Exception:  # pragma: no cover - ambiente sem SDK
    GenAIClientSDK = None  # type: ignore


logger = get_logger("platform")


@runtime_checkable
class ChatBackend(Protocol):
    """Contrato mínimo que o pipeline de chat precisa.
    Isso permite trocar facilmente entre SDK oficial e chamada HTTP crua.
    """

    def chat(
        self,
        *,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        meta: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        ...  # pragma: no cover


@dataclass
class SDKBackend(ChatBackend):
    """Backend usando o SDK oficial `genaisdk`.

    Ajuste o conteúdo do `submit` conforme o contrato real da plataforma.
    A ideia aqui é encapsular o formato esperado pelo SDK.
    """

    client: Any

    @classmethod
    def from_env(cls) -> "SDKBackend":
        if GenAIClientSDK is None:
            raise RuntimeError("genaisdk não está instalado ou não pôde ser importado.")
        # Aqui você configura o client conforme o SDK (token, base_url, projeto, etc.)
        # Exemplo genérico:
        client = GenAIClientSDK(  # type: ignore[call-arg]
            api_key=settings.genai_api_key.get_secret_value(),
            base_url=settings.genai_api_base,
        )
        return cls(client=client)

    def chat(
        self,
        *,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        meta: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "model": model or settings.genai_default_model,
            "messages": messages,
            "temperature": temperature if temperature is not None else settings.genai_temperature,
            "max_tokens": max_tokens if max_tokens is not None else settings.genai_max_tokens,
            "metadata": meta or {},
        }

        # Exemplo genérico usando o método `submit` do SDK.
        # Adapte o `task_type` / `route` / campos extras conforme o contrato real.
        logger.info("Enviando request via SDK genaisdk.submit")
        response = self.client.submit(  # type: ignore[attr-defined]
            task_type="chat.completions",
            payload=payload,
        )
        # Assumindo que o SDK devolve um dicionário tipo OpenAI-like;
        # ajuste aqui se o formato for diferente.
        return response


@dataclass
class HTTPBackend(ChatBackend):
    """Backend HTTP genérico para quem preferir/precisar chamar a API direto."""

    api_key: str
    base_url: str

    @classmethod
    def from_env(cls) -> "HTTPBackend":
        return cls(
            api_key=settings.genai_api_key.get_secret_value().strip(),
            base_url=settings.genai_api_base.rstrip("/"),
        )

    def chat(
        self,
        *,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        meta: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "model": model or settings.genai_default_model,
            "messages": messages,
            "temperature": temperature if temperature is not None else settings.genai_temperature,
            "max_tokens": max_tokens if max_tokens is not None else settings.genai_max_tokens,
            "metadata": meta or {},
        }
        url = f"{self.base_url}/v1/chat/completions"  # ajuste se sua API usar outro path
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        logger.info("Enviando request via HTTP direto")
        with httpx.Client(timeout=60) as client:
            resp = client.post(url, headers=headers, json=payload)
            resp.raise_for_status()
            return resp.json()


def get_backend() -> ChatBackend:
    """Factory para escolher o backend com base em variável de ambiente.

    GENAI_BACKEND=SDK  -> usa genaisdk (se disponível)
    GENAI_BACKEND=HTTP -> usa HTTP cru
    default: SDK se o pacote existir; caso contrário, HTTP.
    """
    backend = os.getenv("GENAI_BACKEND", "").upper()

    if backend == "SDK":
        if GenAIClientSDK is None:
            raise RuntimeError("GENAI_BACKEND=SDK mas genaisdk não está disponível.")
        return SDKBackend.from_env()

    if backend == "HTTP":
        return HTTPBackend.from_env()

    # Default: tenta SDK, cai para HTTP se não der.
    if GenAIClientSDK is not None:
        return SDKBackend.from_env()

    return HTTPBackend.from_env()


# Métodos auxiliares opcionais para expor capacidades do SDK (guardrails, modelos, projetos).
# Você pode usá-los em notebooks para inspeção/descoberta.

def list_models_via_sdk() -> Any:
    if GenAIClientSDK is None:
        raise RuntimeError("genaisdk não está disponível.")
    client = SDKBackend.from_env().client
    return client.list_models()  # type: ignore[attr-defined]


def list_projects_via_sdk() -> Any:
    if GenAIClientSDK is None:
        raise RuntimeError("genaisdk não está disponível.")
    client = SDKBackend.from_env().client
    return client.list_projects()  # type: ignore[attr-defined]


def get_guardrails_via_sdk() -> Any:
    if GenAIClientSDK is None:
        raise RuntimeError("genaisdk não está disponível.")
    client = SDKBackend.from_env().client
    return client.get_guardrails()  # type: ignore[attr-defined]
